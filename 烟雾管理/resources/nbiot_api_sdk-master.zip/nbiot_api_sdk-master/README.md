# nbiot_api_sdk
nbiot_api_sdk
该sdk是对应NB协议接入OneNET平台，对应的接口是官网中：公开协议产品指南——>NB-IOT——>NB-IOT应用开发API中的接口。
